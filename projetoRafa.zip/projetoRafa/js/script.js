const btn = document.querySelector("#send");

btn.addEventListener("click", function(e){

    e.preventDefault();

    const interesse = document.querySelector("#campo_interesse");
    const valueInteresse = interesse.value;
    console.log(valueInteresse)

    const tipo_pessoa = document.querySelector("#tipo_pessoa");
    const valueTipo_pessoa = tipo_pessoa.value;
    console.log(valueTipo_pessoa)

    const name = document.querySelector("#campo_nome");
    const valueName = name.value;
    console.log(valueName)

    const sobrenome = document.querySelector("#campo_sobrenome");
    const valueSobrenome = sobrenome.value;
    console.log(valueSobrenome)

    const cpf = document.querySelector("#campo_cpf");
    const valueCpf = cpf.value;
    console.log(valueCpf)
    
    const celular = document.querySelector("#campo_celular");
    const valueCelular = celular.value;
    console.log(valueCelular)

    const email = document.querySelector("#campo_email");
    const valueEmail = email.value;
    console.log(valueEmail)

    const resumo = document.querySelector("#campo_resumo");
    const valueResumo = resumo.value;
    console.log(valueResumo)
});